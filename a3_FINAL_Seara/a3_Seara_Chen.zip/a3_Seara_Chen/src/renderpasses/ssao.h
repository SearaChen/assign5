/*
    This file is part of TinyRender, an educative rendering system.

    Designed for ECSE 446/546 Realistic/Advanced Image Synthesis.
    Derek Nowrouzezahrai, McGill University.
*/

#pragma once

#include "core/renderpass.h"
#include "tiny_obj_loader.h"

TR_NAMESPACE_BEGIN

/**
 * SSAO (Screen Space Ambient Occlusion) renderpass.
 */
struct SSAOPass : RenderPass {
    GLuint gbuffer;
    GLuint texturePosition;
    GLuint textureNormal;
    GLuint textureDepth;
    GLuint geometryShader;

    GLuint quadVBO;
    GLuint quadVAO;
    GLuint shaderSSAO;

    GLuint uvAttrib{1};

    explicit SSAOPass(const Scene& scene) : RenderPass(scene) { }

    virtual bool init(const Config& config) override {
        RenderPass::init(config);

        // Create vertex buffers
        const auto& shapes = scene.worldData.shapes;
        objects.resize(shapes.size());
        for (size_t i = 0; i < shapes.size(); i++) {
            const tinyobj::shape_t& s = shapes[i];
            GLObject& obj = objects[i];
            buildVBO(i);
            buildVAO(i);
        }

        // Create shader to build GBuffer
        GLuint vs = compileShader("geometry.vs", GL_VERTEX_SHADER);
        GLuint fs = compileShader("geometry.fs", GL_FRAGMENT_SHADER);
        geometryShader = compileProgram(vs, fs);
        glDeleteShader(vs);
        glDeleteShader(fs);

        // Create position texture (GBuffer)
        glGenTextures(1, &texturePosition);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texturePosition);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, config.width, config.height, 0, GL_RGB, GL_FLOAT, NULL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glBindTexture(GL_TEXTURE_2D, 0);

        // Create normal texture (GBuffer)
        glGenTextures(1, &textureNormal);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, textureNormal);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, config.width, config.height, 0, GL_RGB, GL_FLOAT, NULL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glBindTexture(GL_TEXTURE_2D, 0);

        // Create depth texture (GBuffer)
        glGenTextures(1, &textureDepth);
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, textureDepth);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, config.width, config.height, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_BYTE, NULL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glBindTexture(GL_TEXTURE_2D, 0);

        // Create the GBuffer
        glGenFramebuffers(1, &gbuffer);
        glBindFramebuffer(GL_FRAMEBUFFER, gbuffer);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, texturePosition, 0);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_TEXTURE_2D, textureNormal, 0);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, textureDepth, 0);
        unsigned int attachments[2] = {GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1};
        glDrawBuffers(2, attachments);
        GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
        if (status != GL_FRAMEBUFFER_COMPLETE) return false;
        glBindFramebuffer(GL_FRAMEBUFFER, 0);

        // Create quad VBO
        glGenVertexArrays(1, &quadVAO);
        glBindVertexArray(quadVAO);
        GLfloat quadVertices[] = {
            //x, y     u, v
            -1, 1, 0, 1,
            -1, -1, 0, 0,
            1, -1, 1, 0,
            -1, 1, 0, 1,
            1, -1, 1, 0,
            1, 1, 1, 1
        };
        glGenBuffers(1, &quadVBO);
        glBindBuffer(GL_ARRAY_BUFFER, quadVBO);
        glBufferData(GL_ARRAY_BUFFER, 4 * 6 * sizeof(GLfloat), (GLvoid*) (&quadVertices[0]), GL_STATIC_DRAW);
        glEnableVertexAttribArray(posAttrib);
        glEnableVertexAttribArray(uvAttrib);
        glVertexAttribPointer(posAttrib, 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, (GLvoid*)(0 * sizeof(GLfloat)));
        glVertexAttribPointer(uvAttrib, 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, (GLvoid*)(2 * sizeof(GLfloat)));
        // Create SSAO shader
        {
            GLuint vs = compileShader("quad.vs", GL_VERTEX_SHADER);
            GLuint fs = compileShader("ssao.fs", GL_FRAGMENT_SHADER);
            shaderSSAO = compileProgram(vs, fs);
            glDeleteShader(vs);
            glDeleteShader(fs);
        }

        return true;
    }

    virtual void cleanUp() override {
        // Delete GBuffer
        glDeleteTextures(1, &texturePosition);
        glDeleteTextures(1, &textureNormal);
        glDeleteTextures(1, &textureDepth);
        glDeleteFramebuffers(1, &gbuffer);
        glDeleteProgram(geometryShader);

        // Delete SSAO shader
        glDeleteBuffers(1, &quadVBO);
        glDeleteVertexArrays(1, &quadVAO);
        glDeleteProgram(shaderSSAO);

        // Delete vertex buffers
        for (size_t i = 0; i < objects.size(); i++) {
            GLObject obj = objects[i];
            glDeleteBuffers(1, &obj.vbo);
            glDeleteVertexArrays(1, &obj.vao);
        }

        RenderPass::cleanUp();
    }

    virtual void render() override {
        // I. Geometry pass (GBuffer)
        // =======================================================================================
		// Bind the GBuffer
		glBindFramebuffer(GL_FRAMEBUFFER, gbuffer);

        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glEnable(GL_DEPTH_TEST);
        
        // Update camera
        glm::mat4 model, view, projection;
        camera.Update();
        camera.GetMatricies(projection, view, model);


		for (size_t i = 0; i < objects.size(); i++) {
			GLObject obj = objects[i];

			glUseProgram(geometryShader);

			GLuint modelMatUniform = GLuint(glGetUniformLocation(geometryShader, "model"));
			GLuint viewMatUniform = GLuint(glGetUniformLocation(geometryShader, "view"));
			GLuint projectionMatUniform = GLuint(glGetUniformLocation(geometryShader, "projection"));

			glUniformMatrix4fv(modelMatUniform, 1, GL_FALSE, &(modelMat[0][0]));
			glUniformMatrix4fv(viewMatUniform, 1, GL_FALSE, &(view[0][0]));
			glUniformMatrix4fv(projectionMatUniform, 1, GL_FALSE, &(projection[0][0]));

			for (GLObject object : objects) {
				//glEnableVertexAttribArray(0);
				glBindVertexArray(obj.vao);
				glDrawArrays(GL_TRIANGLES, 0, obj.nVerts);
				glDisableVertexAttribArray(0);
			}
		}
        
        // II. SSAO pass
        // =======================================================================================
		glBindFramebuffer(GL_FRAMEBUFFER,postprocess_fboScreen); // i have no idea what i am doing

        
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glDisable(GL_DEPTH_TEST);
        glUseProgram(shaderSSAO);

        // pass necessary uniforms
        glUniform1i(glGetUniformLocation(shaderSSAO, "texturePosition"), 0);
        glUniform1i(glGetUniformLocation(shaderSSAO, "textureNormal"), 1);
        glUniformMatrix4fv(glGetUniformLocation(shaderSSAO, "projection"), 1, GL_FALSE, &(projection[0][0]));

        // bind the textures of normals and positions
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texturePosition);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, textureNormal);

        // bind vao of the quad
        glBindVertexArray(quadVAO);

        // draw the quad
        glDrawArrays(GL_TRIANGLES, 0, 6);

        // unbind
        glBindVertexArray(0);

        glBindTexture(GL_TEXTURE0, 0);
        glBindTexture(GL_TEXTURE1, 0);

        RenderPass::render();
    }

};
TR_NAMESPACE_END
